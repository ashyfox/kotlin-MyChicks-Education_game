package tw.com.syscode.myserver;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;

import tw.com.syscode.myserver.DialogFrame.DialogPage;
import tw.com.syscode.myserver.InterfacePage.global.global;
import tw.com.syscode.myserver.SshPage.sshexec;


public class MainActivity extends AppCompatActivity implements global{
    private Button enter ;
    private Button setting;
    private Switch settingswitch1;
    private Switch settingswitch2;
    private boolean ismain = true;

    private Message mess;
    private Thread thread;
    private String command;
    private String receivedata;
    private String keypath;

    private AlertDialog.Builder builder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // run
        main();
    }
    public void main()
    {
        findid();
        onClick();
    }
    @SuppressLint("LongLogTag")
    private void findid()
    {
        File file = Environment.getExternalStoragePublicDirectory("/Download/"+SERVERKEYNAME);
        keypath = file.getAbsolutePath();

        enter = (Button) findViewById(R.id.mainenterbtn);
        setting = (Button) findViewById(R.id.mainsettingbtn);
        if (Build.VERSION.SDK_INT >= 23) {
            int REQUEST_CODE_CONTACT = 101;
            String[] permissions = {Manifest.permission.WRITE_EXTERNAL_STORAGE};
            //验证是否许可权限
            for (String str : permissions) {
                if (this.checkSelfPermission(str) != PackageManager.PERMISSION_GRANTED) {
                    //申请权限
                    this.requestPermissions(permissions, REQUEST_CODE_CONTACT);
                    return;
                }
            }
        }
    }
    private File getExtermalStoragePublicDir(String albumName) {
        File file = Environment.getExternalStoragePublicDirectory("/Downloads/");
//        File file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if(file.mkdir()){
            File f = new File(file, albumName);
            if(f.mkdir()){
                return f;
            }

        }
        return new File(file, albumName);
    }
    private void onClick()
    {
        enter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Intent
            Intent it = new Intent();
            it.setClass(MainActivity.this,ObjectActivity.class);
            startActivity(it);
            }
        });

        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.activity_setting);
                thread = new Thread(CheckServer);
                thread.start();

                settingswitch1 = (Switch) findViewById(R.id.switch1);
                settingswitch2 = (Switch)findViewById(R.id.switch2);

                settingswitch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(final CompoundButton compoundButton, boolean isChecked) {
                        if(isChecked && compoundButton.isPressed())
                        {
                            command = "cd " + global.SERVERLOCATE + " && forever start server.js ";
                            DialogAlert();
                        }
                        else if(!isChecked && compoundButton.isPressed())
                            {
                                command = "cd " + global.SERVERLOCATE + " && forever stop server.js ";
                                DialogAlert();
                            }
                    }
                });
                settingswitch2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
//                        DialogPage dialog = new DialogPage(MainActivity.this);
                    }
                });
                ismain = false;
            }
        });

    }
    private void DialogAlert()
    {
//        builder = new AlertDialog.Builder(MainActivity.this);
//        builder.setMessage("測試中~").setTitle("Remind")
//                .setPositiveButton("確定", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        thread = new Thread(Connection);
//                        thread.start();
//                    }
//                })
//                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//
//                    }
//                }).show();
        DialogPage dialog = new DialogPage(MainActivity.this,thread.start());
    }
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // TODO Auto-generated method stub
        if (keyCode == KeyEvent.KEYCODE_BACK && ismain) { // 攔截返回鍵
            new AlertDialog.Builder(MainActivity.this)
                    .setTitle("確認視窗")
                    .setMessage("確定要結束應用程式嗎?")
                    .setIcon(R.drawable.ic_launcher_background)
                    .setPositiveButton("確定",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    finish();
                                }
                            })
                    .setNegativeButton("取消",
                            new DialogInterface.OnClickListener() {

                                @Override
                                public void onClick(DialogInterface dialog,
                                                    int which) {
                                    // TODO Auto-generated method stub

                                }
                            }).show();
        }else if(keyCode == KeyEvent.KEYCODE_BACK && !ismain){
            setContentView(R.layout.activity_main);
            ismain = true;
            main();
        }
        return true;
    }
    private Handler receiveServer = new Handler() {
        @Override
        public void handleMessage(Message servermsg) {
            super.handleMessage(servermsg);
            switch (servermsg.what) {
                case 1:
                    thread.interrupt();
                    thread = null;
                    break;
                case 2:
                    thread.interrupt();
                    thread = null;
                    settingswitch1.setChecked(false);
                    break;

                case 100:
                    thread.interrupt();
                    thread = null;
                    settingswitch1.setChecked(true);
                    break;
                case 404:
                    thread.interrupt();
                    thread = null;
                    Toast.makeText(MainActivity.this, "Error server", Toast.LENGTH_SHORT).show();
                    break;

            }
        }
    };
//    private void hello()
//    {
//        runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//
//            }
//        });
//    }
    private Runnable Connection = new Runnable()
    {

        @Override
        public void run() {

            mess = new Message();

            try
            {
                tw.com.syscode.myserver.SshPage.sshexec sshexec = new sshexec(command,keypath);
                mess.what = 1;
            }catch(Exception e) {mess.what = 404;}
            MainActivity.this.receiveServer.sendMessage(mess);
        }
    };
    private Runnable CheckServer = new Runnable(){
        public void run()
        {
            mess = new Message();
            try{
                JSONObject jsonParam = new JSONObject();

                try {
                    jsonParam.put("key","111" );

                } catch (JSONException e) {e.printStackTrace();}

                tw.com.syscode.myserver.AjaxPage.connect connect = new tw.com.syscode.myserver.AjaxPage.connect();
                receivedata = connect.run(jsonParam, "http://"+ SERVERIP+":"+SERVERPORT+"/"+OBJECTLOCATE+"/" + OBJECTADDRESS,"GET");
                mess = new Message();
                Log.d("url",receivedata);
                if("None".equals(receivedata))mess.what = 100;
                else mess.what = 2;
            }catch (Exception e) {mess.what = 404;}

            MainActivity.this.receiveServer.sendMessage(mess);
        }
    };
}
