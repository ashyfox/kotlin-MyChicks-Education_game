package tw.com.syscode.myserver.InterfacePage.global;

/**
 * Created by paoso on 2018/2/6.
 */
public interface global
{
    final String SERVERUSER = "ubuntu";
    final String SERVERPASSWORD = "power0515";
    final String SERVERIP = "13.112.192.203";
    final String SERVERKEYNAME = "myselfweb.pem";
    final String SERVERLOCATE = "myServer/ServerModel/nodejs/";

    final int SERVERSSHPORT = 22;
    final int SERVERPORT = 8501;
    final String OBJECTLOCATE = "ObjectModel";
    final String OBJECTADDRESS = "project";
}

