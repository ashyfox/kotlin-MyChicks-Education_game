package tw.com.syscode.myserver.SshPage;

import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Environment;
import android.util.Log;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelShell;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import tw.com.syscode.myserver.InterfacePage.global.global;

/**
 * Created by paoso on 2018/2/9.
 */

public class sshexec implements global{
    private Session session;
    private File root;
    private String path;
    private File folder;
    String result = "";

    public sshexec(String command,String key)
    {
        connectServer(key);
        execCmd(command);
    }
    private void connectServer(String key)
    {
        JSch jsch = new JSch();
        try {


            jsch.addIdentity(key);
            session = jsch.getSession(SERVERUSER,SERVERIP,SERVERSSHPORT);
            session.setPassword(SERVERPASSWORD);

            java.util.Properties config = new java.util.Properties();
            config.put("StrictHostKeyChecking","no");
            session.setConfig(config);
            session.connect(5000);
        } catch (JSchException e) {
            e.printStackTrace();
        }

    }
    public void execCmd(String command)
    {
        BufferedReader reader = null;
        Channel channel = null;
        try{
            if(command != null)
            {
                channel = session.openChannel("shell");
                InputStream in = channel.getInputStream();
                OutputStream toServer = channel.getOutputStream();
                channel.connect(5000);
                reader = new BufferedReader(new InputStreamReader(in));
                toServer.write((command+"\r\n").getBytes());
                toServer.flush();
                String buf = null;
                result = "";
                while ((buf = reader.readLine()) != null ) {
                    Log.d("test",buf);
                    result += buf;
                }

                reader.close();
            }
        } catch (JSchException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            channel.disconnect();
            session.disconnect();
        }
    }
//
    private String RegularExpress(String str,String re)
    {
        Pattern patt = Pattern.compile(re);
        Matcher matcher = patt.matcher(str);
        if(matcher.find()) return matcher.group(0);
        else return "not match";
    }
}
