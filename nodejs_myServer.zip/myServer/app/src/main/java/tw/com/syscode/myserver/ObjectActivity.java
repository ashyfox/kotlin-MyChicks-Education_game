package tw.com.syscode.myserver;

import android.content.ClipData;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.SubMenu;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import tw.com.syscode.myserver.InterfacePage.global.global;


public class ObjectActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,global {

    private String receivedata;
    private Message mess;
    private Menu menu;
    private SubMenu setting;
    private DrawerLayout drawlayout;
    private WebView webview;
    private Thread thread;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_object);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        thread = new Thread(Connection);
        thread.start();

    }
    public void obj()
    {
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        drawlayout = (DrawerLayout)findViewById(R.id.drawer_layout);

        menu = navigationView.getMenu();

        webview = (WebView) findViewById(R.id.webview);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.getSettings().setLoadWithOverviewMode(true);
        webview.getSettings().setUseWideViewPort(true);
        webview.setWebViewClient(new WebViewClient());

//        setting = menu.addSubMenu("menu2");
//        navigationView.setNavigationItemSelectedListener(this);
    }
    private void addMenu(Menu menu, final String elt)
    {
        menu.add(elt).setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {
                closeDrawers();
                Log.d("test","http://"+SERVERIP+":"+ SERVERPORT+"/"+ OBJECTLOCATE+"/"+OBJECTADDRESS+"/"+elt+"/index.html");
                webview.loadUrl("http://"+ SERVERIP+":"+SERVERPORT+"/"+ OBJECTLOCATE+"/"+OBJECTADDRESS+"/"+elt+"/index.html");
                return false;
            }
        });
    }
    private void closeDrawers(){drawlayout.closeDrawers();}
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.object, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    private Handler receiveServer = new Handler() {
        @Override
        public void handleMessage(Message servermsg) {
            super.handleMessage(servermsg);
            switch (servermsg.what) {
                case 1:
                    int i;
                    Log.d("test",receivedata);
                    obj();
                    try {
                        JSONArray json = new JSONArray(receivedata);
                        for(i = 0 ; i<json.length();i++)
                        {
                            final JSONObject explrObject = json.getJSONObject(i);
                            addMenu(menu,explrObject.getString("data"));

                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    closeDrawers();
                    thread = null;
                    break;

                case 100:
                    Toast.makeText(ObjectActivity.this, "have a error message", Toast.LENGTH_SHORT).show();
                    break;
            }

        }
    };

    private Runnable Connection = new Runnable()
    {
        @Override
        public void run() {

            JSONObject jsonParam = new JSONObject();

            try {
                jsonParam.put("key","111" );

            } catch (JSONException e) {e.printStackTrace();}

            tw.com.syscode.myserver.AjaxPage.connect connect = new tw.com.syscode.myserver.AjaxPage.connect();
            receivedata = connect.run(jsonParam, "http://"+ SERVERIP+":"+ SERVERPORT+"/"+OBJECTLOCATE+"/Package","POST");

            mess = new Message();
            if("None".equals(receivedata))mess.what = 100;
            else mess.what =1;
            ObjectActivity.this.receiveServer.sendMessage(mess);
        }
    };
}
