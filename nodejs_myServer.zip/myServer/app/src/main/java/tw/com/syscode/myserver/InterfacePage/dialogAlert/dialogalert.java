package tw.com.syscode.myserver.InterfacePage.dialogAlert;

import android.app.Activity;

/**
 * Created by paoso on 2018/2/27.
 */

public interface dialogalert {
    void run(Activity activity,String a);
    void close();
}
