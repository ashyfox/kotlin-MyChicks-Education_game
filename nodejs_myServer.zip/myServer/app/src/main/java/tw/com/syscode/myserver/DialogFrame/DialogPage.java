package tw.com.syscode.myserver.DialogFrame;

import android.app.Activity;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;


import tw.com.syscode.myserver.InterfacePage.dialogAlert.dialogalert;



/**
 * Created by paoso on 2018/2/27.
 */

public class DialogPage extends Activity implements dialogalert {
    public DialogPage(Activity activity,String a) { run(activity,a);}
    @Override
    public void run(Activity activity,String a) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setMessage("測試中~").setTitle("Remind")
                .setPositiveButton("確定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).show();
    }

    @Override
    public void close() {

    }
}
