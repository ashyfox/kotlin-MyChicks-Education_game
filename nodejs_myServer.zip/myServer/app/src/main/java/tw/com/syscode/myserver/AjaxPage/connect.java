package tw.com.syscode.myserver.AjaxPage;

import android.text.Html;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by paoso on 2017/10/4.
 */

public class connect {

    public String run(JSONObject alloutput,String url,String type)
    {
        HttpURLConnection conn = null;
        String response = new String();
        try {
            URL urlconn = new URL(url);
            conn = (HttpURLConnection) urlconn.openConnection();
            conn.setRequestMethod(type);
            conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            conn.setRequestProperty("Accept","application/json");


            conn.setUseCaches(false);
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.connect();

            DataOutputStream os = new DataOutputStream(conn.getOutputStream());
            os.write(alloutput.toString().getBytes());
            Log.d("url","pass1");
            os.flush();
            os.close();

            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String line;

            while ((line = reader.readLine()) != null) {
                response+=line;
            }
            reader.close();
            conn.disconnect();
            return response;


        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "None";
    }
}
